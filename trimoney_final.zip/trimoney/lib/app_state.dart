import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _uncategorizedReference =
          prefs.getString('ff_uncategorizedReference')?.ref ??
              _uncategorizedReference;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _inputtext = '';
  String get inputtext => _inputtext;
  set inputtext(String value) {
    _inputtext = value;
  }

  List<String> _msgs = [];
  List<String> get msgs => _msgs;
  set msgs(List<String> value) {
    _msgs = value;
  }

  void addToMsgs(String value) {
    msgs.add(value);
  }

  void removeFromMsgs(String value) {
    msgs.remove(value);
  }

  void removeAtIndexFromMsgs(int index) {
    msgs.removeAt(index);
  }

  void updateMsgsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    msgs[index] = updateFn(_msgs[index]);
  }

  void insertAtIndexInMsgs(int index, String value) {
    msgs.insert(index, value);
  }

  String _surname = '';
  String get surname => _surname;
  set surname(String value) {
    _surname = value;
  }

  bool _searchMode = false;
  bool get searchMode => _searchMode;
  set searchMode(bool value) {
    _searchMode = value;
  }

  bool _isMoney = false;
  bool get isMoney => _isMoney;
  set isMoney(bool value) {
    _isMoney = value;
  }

  DateTime? _toDate = DateTime.fromMillisecondsSinceEpoch(1721413320000);
  DateTime? get toDate => _toDate;
  set toDate(DateTime? value) {
    _toDate = value;
  }

  DateTime? _fromDate = DateTime.fromMillisecondsSinceEpoch(1720808520000);
  DateTime? get fromDate => _fromDate;
  set fromDate(DateTime? value) {
    _fromDate = value;
  }

  DocumentReference? _uncategorizedReference =
      FirebaseFirestore.instance.doc('/categories/d1VBY0oGjt7HUqpRLku5');
  DocumentReference? get uncategorizedReference => _uncategorizedReference;
  set uncategorizedReference(DocumentReference? value) {
    _uncategorizedReference = value;
    value != null
        ? prefs.setString('ff_uncategorizedReference', value.path)
        : prefs.remove('ff_uncategorizedReference');
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
