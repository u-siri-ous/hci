import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'category_legend_model.dart';
export 'category_legend_model.dart';

class CategoryLegendWidget extends StatefulWidget {
  const CategoryLegendWidget({
    super.key,
    required this.colour,
    required this.name,
  });

  final Color? colour;
  final String? name;

  @override
  State<CategoryLegendWidget> createState() => _CategoryLegendWidgetState();
}

class _CategoryLegendWidgetState extends State<CategoryLegendWidget> {
  late CategoryLegendModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CategoryLegendModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Container(
              width: 25.0,
              height: 25.0,
              decoration: BoxDecoration(
                color: widget!.colour,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Flexible(
            child: AutoSizeText(
              valueOrDefault<String>(
                widget!.name,
                'categoryName',
              ),
              textAlign: TextAlign.start,
              minFontSize: 5.0,
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Readex Pro',
                    color: FlutterFlowTheme.of(context).secondary,
                    fontSize: 14.0,
                    letterSpacing: 0.0,
                  ),
            ),
          ),
        ].divide(SizedBox(width: 5.0)),
      ),
    );
  }
}
