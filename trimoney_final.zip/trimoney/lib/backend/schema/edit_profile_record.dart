import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EditProfileRecord extends FirestoreRecord {
  EditProfileRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "surname" field.
  String? _surname;
  String get surname => _surname ?? '';
  bool hasSurname() => _surname != null;

  // "phone_number" field.
  int? _phoneNumber;
  int get phoneNumber => _phoneNumber ?? 0;
  bool hasPhoneNumber() => _phoneNumber != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _surname = snapshotData['surname'] as String?;
    _phoneNumber = castToType<int>(snapshotData['phone_number']);
    _email = snapshotData['email'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('edit_profile');

  static Stream<EditProfileRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => EditProfileRecord.fromSnapshot(s));

  static Future<EditProfileRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => EditProfileRecord.fromSnapshot(s));

  static EditProfileRecord fromSnapshot(DocumentSnapshot snapshot) =>
      EditProfileRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static EditProfileRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      EditProfileRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'EditProfileRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is EditProfileRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createEditProfileRecordData({
  String? name,
  String? surname,
  int? phoneNumber,
  String? email,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'surname': surname,
      'phone_number': phoneNumber,
      'email': email,
    }.withoutNulls,
  );

  return firestoreData;
}

class EditProfileRecordDocumentEquality implements Equality<EditProfileRecord> {
  const EditProfileRecordDocumentEquality();

  @override
  bool equals(EditProfileRecord? e1, EditProfileRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.surname == e2?.surname &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.email == e2?.email;
  }

  @override
  int hash(EditProfileRecord? e) => const ListEquality()
      .hash([e?.name, e?.surname, e?.phoneNumber, e?.email]);

  @override
  bool isValidKey(Object? o) => o is EditProfileRecord;
}
