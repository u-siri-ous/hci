import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ExpensesRecord extends FirestoreRecord {
  ExpensesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "amount" field.
  double? _amount;
  double get amount => _amount ?? 0.0;
  bool hasAmount() => _amount != null;

  // "expense_to" field.
  String? _expenseTo;
  String get expenseTo => _expenseTo ?? '';
  bool hasExpenseTo() => _expenseTo != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "category" field.
  DocumentReference? _category;
  DocumentReference? get category => _category;
  bool hasCategory() => _category != null;

  // "user_id" field.
  DocumentReference? _userId;
  DocumentReference? get userId => _userId;
  bool hasUserId() => _userId != null;

  // "categoryName" field.
  String? _categoryName;
  String get categoryName => _categoryName ?? '';
  bool hasCategoryName() => _categoryName != null;

  void _initializeFields() {
    _amount = castToType<double>(snapshotData['amount']);
    _expenseTo = snapshotData['expense_to'] as String?;
    _date = snapshotData['date'] as DateTime?;
    _category = snapshotData['category'] as DocumentReference?;
    _userId = snapshotData['user_id'] as DocumentReference?;
    _categoryName = snapshotData['categoryName'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('expenses');

  static Stream<ExpensesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ExpensesRecord.fromSnapshot(s));

  static Future<ExpensesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ExpensesRecord.fromSnapshot(s));

  static ExpensesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ExpensesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ExpensesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ExpensesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ExpensesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ExpensesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createExpensesRecordData({
  double? amount,
  String? expenseTo,
  DateTime? date,
  DocumentReference? category,
  DocumentReference? userId,
  String? categoryName,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'amount': amount,
      'expense_to': expenseTo,
      'date': date,
      'category': category,
      'user_id': userId,
      'categoryName': categoryName,
    }.withoutNulls,
  );

  return firestoreData;
}

class ExpensesRecordDocumentEquality implements Equality<ExpensesRecord> {
  const ExpensesRecordDocumentEquality();

  @override
  bool equals(ExpensesRecord? e1, ExpensesRecord? e2) {
    return e1?.amount == e2?.amount &&
        e1?.expenseTo == e2?.expenseTo &&
        e1?.date == e2?.date &&
        e1?.category == e2?.category &&
        e1?.userId == e2?.userId &&
        e1?.categoryName == e2?.categoryName;
  }

  @override
  int hash(ExpensesRecord? e) => const ListEquality().hash([
        e?.amount,
        e?.expenseTo,
        e?.date,
        e?.category,
        e?.userId,
        e?.categoryName
      ]);

  @override
  bool isValidKey(Object? o) => o is ExpensesRecord;
}
