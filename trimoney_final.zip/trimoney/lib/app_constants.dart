import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const String Uncategorized = '/categories/d1VBY0oGjt7HUqpRLku5';
}
