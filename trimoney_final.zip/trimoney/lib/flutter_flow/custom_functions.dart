import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

List<DocumentReference> generateListOfUsers(
  DocumentReference authUser,
  DocumentReference otherUser,
) {
  return [authUser, otherUser];
}

List<String> generateListOfNames(
  String authUserName,
  String otherUserName,
) {
  return [authUserName, otherUserName];
}

DocumentReference getOtherUserRef(
  List<DocumentReference> listOfUserRefs,
  DocumentReference authUserRef,
) {
  return authUserRef == listOfUserRefs.first
      ? listOfUserRefs.last
      : listOfUserRefs.first;
}

String getOtherUserName(
  List<String> listOfNames,
  String authUserName,
) {
  return authUserName == listOfNames.first
      ? listOfNames.last
      : listOfNames.first;
}

bool chatExists(
  List<ChatsRecord> allChats,
  DocumentReference authUserRef,
  DocumentReference otherUserRef,
) {
  for (final chat in allChats) {
    if (chat.userIds.contains(authUserRef) &&
        chat.userIds.contains(otherUserRef)) {
      return true;
    }
  }
  return false;
}

List<ExpensesRecord> sortUncategorised(List<ExpensesRecord> allExpenses) {
  // return a list called uncategorizedExpenses that contains the documents in allExpenses which have their category, that is of the document reference type, equal to "d1VBY0oGjt7HUqpRLku5"
  List<ExpensesRecord> uncategorizedExpenses = allExpenses
      .where((expense) => expense.categoryName == "Uncategorized")
      .toList();
  return uncategorizedExpenses;
}

DateTime oneWeekBack(DateTime date1) {
  DateTime date2 = date1.subtract(Duration(days: 7));
  return date2;
}

double? sumExpenses(List<ExpensesRecord>? expenses) {
  // you get a list of expenses documents, sum the amount field and return it as a string
  if (expenses == null || expenses.isEmpty) {
    return 0.0;
  }

  double totalAmount = 0.0;
  for (final expense in expenses) {
    totalAmount += expense.amount ?? 0.0;
  }

  return totalAmount;
}

List<ExpensesRecord> sortCategorised(List<ExpensesRecord> allExpenses) {
  List<ExpensesRecord> categorizedExpenses = allExpenses
      .where((expense) => expense.categoryName != "Uncategorized")
      .toList();
  return categorizedExpenses;
}

double? getPercentage(
  CategoriesRecord category,
  List<ExpensesRecord> allExpenses,
  double totalExpense,
) {
  double count = 0.0;
  for (ExpensesRecord expense in allExpenses) {
    if (expense.categoryName == category.name) {
      count += expense.amount;
    } else {
      continue;
    }
  }
  return (count / totalExpense) * 100;
}

Color darkenColor(
  Color color1,
  double amount,
) {
  assert(amount >= 0.0 && amount <= 1.0);

  final hsl = HSLColor.fromColor(color1);
  final hslDark = hsl.withLightness((hsl.lightness - amount).clamp(0.0, 1.0));
  return hslDark.toColor();
}

double roundPercentage(double percentage) {
  return ((percentage * 10).ceil()) / 10;
}
