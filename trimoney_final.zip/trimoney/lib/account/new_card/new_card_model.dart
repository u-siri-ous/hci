import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'new_card_widget.dart' show NewCardWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

class NewCardModel extends FlutterFlowModel<NewCardWidget> {
  ///  Local state fields for this page.

  DocumentReference? cards;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for OwnerName widget.
  FocusNode? ownerNameFocusNode;
  TextEditingController? ownerNameTextController;
  String? Function(BuildContext, String?)? ownerNameTextControllerValidator;
  // State field(s) for CardNumber widget.
  FocusNode? cardNumberFocusNode;
  TextEditingController? cardNumberTextController;
  final cardNumberMask = MaskTextInputFormatter(mask: '#### #### #### ####');
  String? Function(BuildContext, String?)? cardNumberTextControllerValidator;
  // State field(s) for ExpDate widget.
  FocusNode? expDateFocusNode;
  TextEditingController? expDateTextController;
  final expDateMask = MaskTextInputFormatter(mask: '##/##/####');
  String? Function(BuildContext, String?)? expDateTextControllerValidator;
  // State field(s) for CVV widget.
  FocusNode? cvvFocusNode;
  TextEditingController? cvvTextController;
  final cvvMask = MaskTextInputFormatter(mask: '###');
  String? Function(BuildContext, String?)? cvvTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    ownerNameFocusNode?.dispose();
    ownerNameTextController?.dispose();

    cardNumberFocusNode?.dispose();
    cardNumberTextController?.dispose();

    expDateFocusNode?.dispose();
    expDateTextController?.dispose();

    cvvFocusNode?.dispose();
    cvvTextController?.dispose();
  }
}
