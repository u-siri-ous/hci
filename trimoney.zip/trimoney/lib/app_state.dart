import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _inputtext = '';
  String get inputtext => _inputtext;
  set inputtext(String value) {
    _inputtext = value;
  }

  List<String> _msgs = [];
  List<String> get msgs => _msgs;
  set msgs(List<String> value) {
    _msgs = value;
  }

  void addToMsgs(String value) {
    msgs.add(value);
  }

  void removeFromMsgs(String value) {
    msgs.remove(value);
  }

  void removeAtIndexFromMsgs(int index) {
    msgs.removeAt(index);
  }

  void updateMsgsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    msgs[index] = updateFn(_msgs[index]);
  }

  void insertAtIndexInMsgs(int index, String value) {
    msgs.insert(index, value);
  }
}
