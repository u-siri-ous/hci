import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/transfer/messagebox/messagebox_widget.dart';
import 'chat_page_widget.dart' show ChatPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChatPageModel extends FlutterFlowModel<ChatPageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for messagebox component.
  late MessageboxModel messageboxModel;

  @override
  void initState(BuildContext context) {
    messageboxModel = createModel(context, () => MessageboxModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    messageboxModel.dispose();
  }
}
