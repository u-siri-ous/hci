import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCnXzR45kX8RSM70fI1P_W7lCNn83Qb5Cs",
            authDomain: "trimoney-cghxlc.firebaseapp.com",
            projectId: "trimoney-cghxlc",
            storageBucket: "trimoney-cghxlc.appspot.com",
            messagingSenderId: "892273409223",
            appId: "1:892273409223:web:bfc2e72660873c081212e2"));
  } else {
    await Firebase.initializeApp();
  }
}
