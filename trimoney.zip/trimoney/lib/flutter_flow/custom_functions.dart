import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

List<DocumentReference> generateListOfUsers(
  DocumentReference authUser,
  DocumentReference otherUser,
) {
  return [authUser, otherUser];
}

List<String> generateListOfNames(
  String authUserName,
  String otherUserName,
) {
  return [authUserName, otherUserName];
}

DocumentReference getOtherUserRef(
  List<DocumentReference> listOfUserRefs,
  DocumentReference authUserRef,
) {
  return authUserRef == listOfUserRefs.first
      ? listOfUserRefs.last
      : listOfUserRefs.first;
}

String getOtherUserName(
  List<String> listOfNames,
  String authUserName,
) {
  return authUserName == listOfNames.first
      ? listOfNames.last
      : listOfNames.first;
}

bool chatExists(
  List<ChatsRecord> allChats,
  DocumentReference authUserRef,
  DocumentReference otherUserRef,
) {
  for (final chat in allChats) {
    if (chat.userIds.contains(authUserRef) &&
        chat.userIds.contains(otherUserRef)) {
      return true;
    }
  }
  return false;
}

List<ExpensesRecord> sortUncategorised(List<ExpensesRecord> allExpenses) {
  // return a list called uncategorizedExpenses that contains the documents in allExpenses which have their category, that is of the document reference type, equal to "d1VBY0oGjt7HUqpRLku5"
  List<ExpensesRecord> uncategorizedExpenses = allExpenses
      .where((expense) =>
          expense?.category.toString() == "/categories/d1VBY0oGjt7HUqpRLku5")
      .toList();
  return uncategorizedExpenses;
}

DateTime oneWeekBack(DateTime date1) {
  DateTime date2 = date1.subtract(Duration(days: 7));
  return date2;
}
